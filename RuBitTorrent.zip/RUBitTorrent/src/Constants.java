import java.io.File;
import java.util.logging.Level;

/**
 *	Contains constants used in program
 */
public class Constants {

	/** filename of logfile for logging=enabled. */
	public static String logFile = "BT.Log";

	/** Enable file logging. */
	public static boolean fileLoggingEnabled = false;

	/** Enable console logging. */
	public static boolean consoleLoggingEnabled = false;

	/**
	 * sets level required for message logging
	 */
	public static Level logLevel = Level.OFF;
	
	/** statistics file */
	public static File stats = new File("song.mp3.stats");

}
